#!/bin/bash

function __kob_list {

echo printout list

# https://raw.githubusercontent.com/TrinityGroup/KOBDevOps/master/list | less

}
