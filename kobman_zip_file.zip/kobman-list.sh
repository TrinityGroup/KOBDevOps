		https://raw.githubusercontent.com/EtricKombat/KOBDevOps/master/list | less
