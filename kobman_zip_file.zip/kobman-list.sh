#!/bin/bash

function __kob_list {
curl -L "https://raw.githubusercontent.com/TrinityGroup/KOBDevOps/master/list" | less

# https://raw.githubusercontent.com/TrinityGroup/KOBDevOps/master/list | less

}
