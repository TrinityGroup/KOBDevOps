#!/bin/bash

function __kob_proxy{

figlet Proxy -f small
figlet settings -f small

}
