#!/bin/bash

function __kob_proxy {
sudo figlet proxy -f small
sudo figlet setting -f small

}
