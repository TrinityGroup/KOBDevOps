#!/bin/bash

function __kob_proxy{
sudo figlet Proxy--Settings

}
