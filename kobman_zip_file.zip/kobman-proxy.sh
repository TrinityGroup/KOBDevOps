#!/bin/bash

function __kob_proxy{

sudo figlet Proxy -f small
sudo figlet settings -f small

}
