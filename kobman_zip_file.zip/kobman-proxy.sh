#!/bin/bash


function __kob_proxy {

        local command qualifier three name_space

        command=$COMMAND
        qualifier=$QUALIFIER
        three=$THREE
        name_space=$NAME_SPACE

        if [ "$command" = "proxy" ]
        then
                case $qualifier in
                --set)
                        figlet setting proxy
		;;
		--unset)
			figlet unsetting proxy
		;;
		*)
		;;	
	fi			
}
